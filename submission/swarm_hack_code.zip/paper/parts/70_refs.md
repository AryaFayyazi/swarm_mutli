## References
REF: [1] Fayyazi, A., et al. (2026). The Agent Knew: Internal States Forecast Unauthorized Actions and Stop Them, and the Lies That Follow. arXiv:2610.17301. https://arxiv.org/abs/2610.17301
REF: [2] Hammond, L., et al. (2025). Multi-Agent Risks from Advanced AI. arXiv:2502.14143. https://arxiv.org/abs/2502.14143
REF: [3] Lee, D., et al. (2024). Prompt Infection: LLM-to-LLM Prompt Injection within Multi-Agent Systems. arXiv:2410.07283. https://arxiv.org/abs/2410.07283
REF: [4] Cemri, M., et al. (2025). Why Do Multi-Agent LLM Systems Fail? arXiv:2503.13657. https://arxiv.org/abs/2503.13657
REF: [5] Greenblatt, R., et al. (2023). AI Control: Improving Safety Despite Intentional Subversion. arXiv:2312.06942. https://arxiv.org/abs/2312.06942
REF: [6] Bhatt, A., et al. (2025). Ctrl-Z: Controlling AI Agents via Resampling. arXiv:2504.10374. https://arxiv.org/abs/2504.10374
REF: [7] Ji, Z., et al. (2026). Taming Various Privilege Escalation in LLM-Based Agent Systems: A Mandatory Access Control Framework. arXiv:2601.11893. https://arxiv.org/abs/2601.11893
REF: [8] Mellafe Zuvic, D. (2026). Capability Gates Are Not Authorization: Confused-Deputy Failures in LLM Agent Frameworks. arXiv:2606.28679. https://arxiv.org/abs/2606.28679
REF: [9] Dantuluri, P. S. V., et al. (2026). Delegation Without Trust: An Empirical Gap Analysis of Identity, Authorization, and Runtime Governance in Multi-Agent LLM Systems. arXiv:2609.00267. https://arxiv.org/abs/2609.00267
REF: [10] Prakash, S. (2026). The Provenance Paradox in Multi-Agent LLM Routing: Delegation Contracts and Attested Identity in LDP. arXiv:2603.18043. https://arxiv.org/abs/2603.18043
REF: [11] Rose, A., et al. (2026). Detecting Multi-Agent Collusion Through Multi-Agent Interpretability. arXiv:2604.01151. https://arxiv.org/abs/2604.01151
REF: [12] Korbak, T., et al. (2025). Chain of Thought Monitorability: A New and Fragile Opportunity for AI Safety. arXiv:2507.11473. https://arxiv.org/abs/2507.11473
REF: [13] METR (2026). Brief independent investigation of agents' behavior, reasoning and collaboration in the OpenAI / Hugging Face hacking incident (Hugging Face incident investigation report), 26 August 2026. https://metr.org/hugging-face-incident-report-aug-2026.pdf
